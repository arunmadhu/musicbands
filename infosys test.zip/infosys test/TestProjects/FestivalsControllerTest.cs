﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestProjects
{
    [TestClass]
    public class FestivalsControllerTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
